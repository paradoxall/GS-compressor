PROGRAM: InstallSimple FREE
VERSION: 3.0 (February 7, 2018)
STATUS: FREEWARE

DESCRIPTION:
Install Simple is a very compact and powerful utility to build
installation packages in seconds instead of hours!
Setups are packed into single exe-file for easy distribution.
The extractor module has extremely small size (only 24 KB overhead over
compressed data size). Using a very practical and intuitive assistant,
you can establish parameters for the installation process of your product
for any Windows platform.

Designed for anyone who distributes applications, data files,
graphic images or whatever else you want to distribute!

SYSTEM REQUIREMENTS:
1. Operating Systems: Windows (95 and newer)

INSTALLATION:
To install InstallSimple simply unzip install-simple.zip
and run Setup.exe

CONTACTS:
E-mail: info@InstallSimple.com
http://www.InstallSimple.com/

Copyright (c) 2007-2018, InstallSimple Solutions. All rights reserved.